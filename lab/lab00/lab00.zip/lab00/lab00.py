def twenty_twenty_six():
    """Come up with the most creative expression that evaluates to 2026
    using only numbers and the +, *, and - operators (or ** and % if you'd like).

    >>> twenty_twenty_six()
    2026
    """
    return ______

